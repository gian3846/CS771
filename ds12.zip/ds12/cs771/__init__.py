'''
	Package: cs771
	Author: Puru (purushot@cse.iitk.ac.in)
	Institution: CSE, IIT Kanpur
	License: GNU GPL 3.0

	Provide various functionalities useful in machine learning lectures
'''